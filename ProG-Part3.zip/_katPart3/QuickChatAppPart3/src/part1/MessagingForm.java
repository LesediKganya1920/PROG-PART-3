package part1;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MessagingForm extends JFrame {
    private final String loggedInUser;
    private JTextArea displayArea;
    private JButton sendButton, viewButton, advancedButton, quitButton;

    public MessagingForm(String username) {
        this.loggedInUser = username;
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("QuickChat - Messaging Menu");
        setSize(550, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("Welcome, " + loggedInUser + "!");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        displayArea.setMargin(new Insets(10, 10, 10, 10));
        displayArea.setBackground(Color.WHITE);
        displayArea.setForeground(Color.BLACK);
        displayArea.setText("QUICKCHAT MESSAGING SYSTEM\n\nSelect an option from the menu below:\n\n1. Send Messages\n2. View Messages\n3. Advanced Features (Part 3)\n4. Quit\n");
        JScrollPane scrollPane = new JScrollPane(displayArea);
        add(scrollPane, BorderLayout.CENTER);

        // Updated to 4 columns for Part 3 button
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 5, 0));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        sendButton = new JButton("1. Send");
        sendButton.setBackground(new Color(255, 223, 0)); // Yellow
        sendButton.setForeground(Color.BLACK);
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sendButton.setFocusPainted(false);
        sendButton.addActionListener(e -> openSendMessageForm());

        viewButton = new JButton("2. View");
        viewButton.setBackground(new Color(255, 105, 180)); // Pink
        viewButton.setForeground(Color.WHITE);
        viewButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewButton.setFocusPainted(false);
        viewButton.addActionListener(e -> viewMessages());

        // NEW: Part 3 Advanced Features Button
        advancedButton = new JButton("3. Advanced");
        advancedButton.setBackground(new Color(138, 43, 226)); // Purple
        advancedButton.setForeground(Color.WHITE);
        advancedButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        advancedButton.setFocusPainted(false);
        advancedButton.addActionListener(e -> openAdvancedFeatures());

        quitButton = new JButton("4. Quit");
        quitButton.setBackground(new Color(128, 128, 128)); // Gray
        quitButton.setForeground(Color.WHITE);
        quitButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        quitButton.setFocusPainted(false);
        quitButton.addActionListener(e -> quitApplication());

        buttonPanel.add(sendButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(advancedButton);
        buttonPanel.add(quitButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void openSendMessageForm() {
        String input = JOptionPane.showInputDialog(this, "How many messages would you like to send?", "Message Quantity", JOptionPane.QUESTION_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            try {
                int quantity = Integer.parseInt(input.trim());
                if (quantity > 0) {
                    new SendMessageForm(this, loggedInUser, quantity).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Please enter a positive number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewMessages() {
        try {
            List<Message> messages = MessageStorage.loadMessages();
            
            if (messages.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "No messages found in storage.\nSend some messages first!", 
                    "No Messages", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            // Create a clean display using MessageManager for consistency
            MessageManager messageManager = new MessageManager();
            StringBuilder sb = new StringBuilder();
            sb.append("=== QUICKCHAT MESSAGE HISTORY ===\n\n");
            sb.append("Total Messages in Storage: ").append(messages.size()).append("\n");
            sb.append("Total Sent Messages: ").append(messageManager.getSentCount()).append("\n");
            sb.append("Total Stored Messages: ").append(messageManager.getStoredCount()).append("\n");
            sb.append("Total Disregarded Messages: ").append(messageManager.getDisregardedCount()).append("\n\n");

            int messageNumber = 1;
            for (Message msg : messages) {
                sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
                sb.append("MESSAGE #").append(messageNumber).append("\n");
                sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
                sb.append("ID: ").append(msg.generateId()).append("\n");
                sb.append("Hash: ").append(msg.generateHash(messageNumber)).append("\n");
                sb.append("Sender: ").append(msg.getSender()).append("\n");
                sb.append("Recipient: ").append(msg.getPhone()).append("\n");
                sb.append("Action: ").append(msg.getAction()).append("\n");
                sb.append("Content: ").append(msg.getText()).append("\n");
                sb.append("Length: ").append(msg.getText().length()).append(" characters\n");
                sb.append("Status: ").append(msg.validateLength()).append("\n");
                sb.append("Phone Valid: ").append(msg.validatePhone()).append("\n");
                sb.append("\n");
                messageNumber++;
            }

            // Display in text area
            displayArea.setText(sb.toString());
            
            // Also show success dialog
            JOptionPane.showMessageDialog(this, 
                "Loaded " + messages.size() + " messages successfully!", 
                "Messages Loaded", 
                JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading messages: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void openAdvancedFeatures() {
        dispose(); // Close current window
        new AdvancedMessagingForm(loggedInUser).setVisible(true);
    }

    private void quitApplication() {
        MessageManager messageManager = new MessageManager();
        int totalInStorage = MessageStorage.loadMessages().size();
        int totalSent = messageManager.getSentCount();
        
        JOptionPane.showMessageDialog(this, 
            "Message Statistics:\n" +
            "• Total in Storage: " + totalInStorage + "\n" +
            "• Total Sent: " + totalSent + "\n" +
            "• Total Stored: " + messageManager.getStoredCount() + "\n" +
            "• Total Disregarded: " + messageManager.getDisregardedCount() + "\n\n" +
            "Thank you for using QuickChat!", 
            "Goodbye", 
            JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MessagingForm("TestUser").setVisible(true));
    }
}