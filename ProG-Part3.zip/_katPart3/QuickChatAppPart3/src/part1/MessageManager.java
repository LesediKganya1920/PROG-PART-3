package part1;

import java.util.*;

public class MessageManager {
    // Arrays as specified in Part 3 requirements
    private Message[] sentMessages;
    private Message[] disregardedMessages; 
    private Message[] storedMessages;
    private String[] messageHashes;
    private String[] messageIDs;
    
    private int sentCount = 0;
    private int disregardedCount = 0;
    private int storedCount = 0;
    private int hashCount = 0;
    private int idCount = 0;

    public MessageManager() {
        // Initialize arrays with reasonable sizes
        sentMessages = new Message[100];
        disregardedMessages = new Message[100];
        storedMessages = new Message[100];
        messageHashes = new String[100];
        messageIDs = new String[100];
        
        // Load existing messages from storage into arrays
        loadMessagesIntoArrays();
    }

    private void loadMessagesIntoArrays() {
        List<Message> allMessages = MessageStorage.loadMessages();
        for (Message msg : allMessages) {
            String action = msg.getAction();
            if (action != null) {
                switch (action.toLowerCase()) {
                    case "send":
                        if (sentCount < sentMessages.length) {
                            sentMessages[sentCount++] = msg;
                        }
                        break;
                    case "store":
                        if (storedCount < storedMessages.length) {
                            storedMessages[storedCount++] = msg;
                        }
                        break;
                    case "discard":
                        if (disregardedCount < disregardedMessages.length) {
                            disregardedMessages[disregardedCount++] = msg;
                        }
                        break;
                }
            }
            
            // Add to hash and ID arrays
            if (hashCount < messageHashes.length) {
                messageHashes[hashCount++] = msg.generateHash(getMessageCount() + 1);
            }
            if (idCount < messageIDs.length) {
                messageIDs[idCount++] = msg.generateId();
            }
        }
    }

    public void addMessage(Message message, String action) {
        // Add to appropriate array based on action
        switch (action.toLowerCase()) {
            case "send":
                if (sentCount < sentMessages.length) {
                    sentMessages[sentCount++] = message;
                }
                break;
            case "store":
                if (storedCount < storedMessages.length) {
                    storedMessages[storedCount++] = message;
                }
                break;
            case "discard":
                if (disregardedCount < disregardedMessages.length) {
                    disregardedMessages[disregardedCount++] = message;
                }
                break;
        }
        
        // Add to hash and ID arrays
        if (hashCount < messageHashes.length) {
            messageHashes[hashCount++] = message.generateHash(getMessageCount());
        }
        if (idCount < messageIDs.length) {
            messageIDs[idCount++] = message.generateId();
        }
        
        // Also save to JSON storage
        MessageStorage.saveMessage(message);
    }

    // Part 3 Required Functionality

    // a. Display sender and recipient of all sent messages
    public String displaySendersAndRecipients() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== SENDERS AND RECIPIENTS OF SENT MESSAGES ===\n");
        for (int i = 0; i < sentCount; i++) {
            sb.append("From: ").append(sentMessages[i].getSender())
              .append(" | To: ").append(sentMessages[i].getPhone())
              .append("\n");
        }
        return sb.toString();
    }

    // b. Display the longest sent message
    public Message displayLongestMessage() {
        if (sentCount == 0) return null;
        
        Message longest = sentMessages[0];
        for (int i = 1; i < sentCount; i++) {
            if (sentMessages[i].getText().length() > longest.getText().length()) {
                longest = sentMessages[i];
            }
        }
        return longest;
    }

    // c. Search for a message ID and display recipient and message
    public Message searchByMessageID(String messageID) {
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i].generateId().equals(messageID)) {
                return sentMessages[i];
            }
        }
        return null;
    }

    // d. Search for all messages sent to a particular recipient
    public Message[] searchByRecipient(String recipient) {
        Message[] results = new Message[sentCount];
        int count = 0;
        
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i].getPhone().equals(recipient)) {
                results[count++] = sentMessages[i];
            }
        }
        return Arrays.copyOf(results, count);
    }

    // e. Delete a message using the message hash
    public boolean deleteMessageByHash(String messageHash) {
        for (int i = 0; i < sentCount; i++) {
            if (messageHashes[i] != null && messageHashes[i].equals(messageHash)) {
                // Shift remaining elements
                for (int j = i; j < sentCount - 1; j++) {
                    sentMessages[j] = sentMessages[j + 1];
                    messageHashes[j] = messageHashes[j + 1];
                    messageIDs[j] = messageIDs[j + 1];
                }
                sentMessages[--sentCount] = null;
                messageHashes[sentCount] = null;
                messageIDs[sentCount] = null;
                return true;
            }
        }
        return false;
    }

    // f. Display report that lists full details of all sent messages
    public String displayFullReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== FULL MESSAGE REPORT ===\n");
        sb.append("Total Sent Messages: ").append(sentCount).append("\n\n");
        
        for (int i = 0; i < sentCount; i++) {
            sb.append("Message ").append(i + 1).append(":\n");
            sb.append("  Message Hash: ").append(messageHashes[i]).append("\n");
            sb.append("  Recipient: ").append(sentMessages[i].getPhone()).append("\n");
            sb.append("  Message: ").append(sentMessages[i].getText()).append("\n");
            sb.append("  Sender: ").append(sentMessages[i].getSender()).append("\n");
            sb.append("  Message ID: ").append(messageIDs[i]).append("\n");
            sb.append("  Status: ").append(sentMessages[i].getAction()).append("\n\n");
        }
        return sb.toString();
    }

    // Getters for unit testing
    public Message[] getSentMessages() { 
        return Arrays.copyOf(sentMessages, sentCount); 
    }
    
    public Message[] getDisregardedMessages() { 
        return Arrays.copyOf(disregardedMessages, disregardedCount); 
    }
    
    public Message[] getStoredMessages() { 
        return Arrays.copyOf(storedMessages, storedCount); 
    }
    
    public String[] getMessageHashes() { 
        return Arrays.copyOf(messageHashes, hashCount); 
    }
    
    public String[] getMessageIDs() { 
        return Arrays.copyOf(messageIDs, idCount); 
    }
    
    public int getSentCount() { return sentCount; }
    public int getDisregardedCount() { return disregardedCount; }
    public int getStoredCount() { return storedCount; }
    public int getMessageCount() { return sentCount + disregardedCount + storedCount; }
}