package part1;

import javax.swing.*;
import java.awt.*;

public class SendMessageForm extends JFrame {
    private MessagingForm parent;
    private String sender;
    private int totalMessages;
    private int currentMessageIndex = 0;
    private JTextField recipientField;
    private JTextArea contentArea;
    private JLabel counterLabel;
    private JButton sendButton, storeButton, discardButton;

    public SendMessageForm(MessagingForm parent, String sender, int totalMessages) {
        this.parent = parent;
        this.sender = sender;
        this.totalMessages = totalMessages;
        initComponents();
        updateCounter();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setTitle("QuickChat - Send Message");
        setSize(550, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("Create New Message");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        counterLabel = new JLabel();
        counterLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        counterLabel.setForeground(Color.BLACK);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        formPanel.add(counterLabel, gbc);

        gbc.gridwidth = 1; gbc.gridy = 1; gbc.gridx = 0; gbc.weightx = 0.3;
        formPanel.add(new JLabel("From:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JTextField senderField = new JTextField(sender);
        senderField.setEditable(false);
        senderField.setBackground(Color.LIGHT_GRAY);
        formPanel.add(senderField, gbc);

        gbc.gridy = 2; gbc.gridx = 0; gbc.weightx = 0.3;
        formPanel.add(new JLabel("To (Phone):"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        recipientField = new JTextField();
        formPanel.add(recipientField, gbc);

        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        formPanel.add(new JLabel("Message (max 250 chars):"), gbc);
        gbc.gridy = 4; gbc.weighty = 1.0; gbc.fill = GridBagConstraints.BOTH;
        contentArea = new JTextArea(8, 30);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        formPanel.add(new JScrollPane(contentArea), gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(Color.WHITE);
        sendButton = new JButton("Send");
        sendButton.setBackground(Color.BLACK);
        sendButton.setForeground(Color.WHITE);
        sendButton.setFocusPainted(false);
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendButton.addActionListener(e -> handleMessage("Send"));

        storeButton = new JButton("Store");
        storeButton.setBackground(Color.DARK_GRAY);
        storeButton.setForeground(Color.WHITE);
        storeButton.setFocusPainted(false);
        storeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        storeButton.addActionListener(e -> handleMessage("Store"));

        discardButton = new JButton("Discard");
        discardButton.setBackground(Color.WHITE);
        discardButton.setForeground(Color.BLACK);
        discardButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        discardButton.addActionListener(e -> discardMessage());

        buttonPanel.add(sendButton);
        buttonPanel.add(storeButton);
        buttonPanel.add(discardButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void updateCounter() {
        counterLabel.setText("Message " + (currentMessageIndex + 1) + " of " + totalMessages);
    }

    private void handleMessage(String action) {
        String recipient = recipientField.getText().trim();
        String content = contentArea.getText().trim();

        if (recipient.isEmpty() || content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!recipient.matches("^\\+\\d{11,15}$")) {
            JOptionPane.showMessageDialog(this, "Recipient phone must be in international format (+country code and 11-15 digits).\nExample: +27123456789", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (content.length() > 250) {
            JOptionPane.showMessageDialog(this, "Message content must be 250 characters or less.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Message message = new Message(sender, recipient, content, action);
        MessageStorage.saveMessage(message);

        String actionDisplay = action.toLowerCase();
        new MessageDetailsDialog(this, message, actionDisplay).setVisible(true);

        currentMessageIndex++;
        if (currentMessageIndex < totalMessages) {
            recipientField.setText("");
            contentArea.setText("");
            updateCounter();
        } else {
            JOptionPane.showMessageDialog(this, "All messages completed!", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        }
    }

    private void discardMessage() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to discard this message?", "Confirm Discard", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            currentMessageIndex++;
            if (currentMessageIndex < totalMessages) {
                recipientField.setText("");
                contentArea.setText("");
                updateCounter();
            } else {
                dispose();
            }
        }
    }

    public static void main(String[] args) {
        MessagingForm dummyParent = new MessagingForm("TestUser");
        new SendMessageForm(dummyParent, "TestUser", 1).setVisible(true);
    }
}