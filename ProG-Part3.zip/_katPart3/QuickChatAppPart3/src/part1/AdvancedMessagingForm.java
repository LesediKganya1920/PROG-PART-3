package part1;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AdvancedMessagingForm extends JFrame {
    private final String loggedInUser;
    private MessageManager messageManager;
    private JTextArea displayArea;

    public AdvancedMessagingForm(String username) {
        this.loggedInUser = username;
        this.messageManager = new MessageManager();
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("QuickChat - Advanced Features (Part 3)");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.DARK_GRAY);
        JLabel headerLabel = new JLabel("Advanced Messaging Features - Part 3");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Display Area
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        displayArea.setBackground(Color.BLACK);
        displayArea.setForeground(Color.GREEN);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        add(scrollPane, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);

        displayArea.setText("=== PART 3 - ADVANCED MESSAGING FEATURES ===\n\n" +
                          "1. Display Senders & Recipients\n" +
                          "2. Find Longest Message\n" + 
                          "3. Search by Message ID\n" +
                          "4. Search by Recipient\n" +
                          "5. Delete by Hash\n" +
                          "6. Full Report\n" +
                          "7. Back to Main\n\n" +
                          "Total Messages in System: " + messageManager.getMessageCount());
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 4, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(Color.WHITE);

        String[] buttons = {
            "1. Senders/Recipients", "2. Longest Message", "3. Search by ID", "4. Search by Recipient",
            "5. Delete by Hash", "6. Full Report", "7. Run All Tests", "8. Back to Main"
        };

        Color[] colors = {
            new Color(70, 130, 180), new Color(60, 179, 113), new Color(255, 140, 0), new Color(147, 112, 219),
            new Color(220, 20, 60), new Color(255, 215, 0), new Color(50, 205, 50), new Color(128, 128, 128)
        };

        for (int i = 0; i < buttons.length; i++) {
            JButton button = createStyledButton(buttons[i], colors[i]);
            final int index = i;
            button.addActionListener(e -> handleButtonClick(index));
            panel.add(button);
        }

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setFocusPainted(false);
        return button;
    }

    private void handleButtonClick(int index) {
        switch (index) {
            case 0: // Senders/Recipients
                displayArea.setText(messageManager.displaySendersAndRecipients());
                break;
            case 1: // Longest Message
                Message longest = messageManager.displayLongestMessage();
                if (longest != null) {
                    displayArea.setText("=== LONGEST MESSAGE ===\n\n" +
                                      "Length: " + longest.getText().length() + " characters\n\n" +
                                      "From: " + longest.getSender() + "\n" +
                                      "To: " + longest.getPhone() + "\n" +
                                      "Message: " + longest.getText() + "\n" +
                                      "Hash: " + longest.generateHash(1));
                } else {
                    displayArea.setText("No sent messages found.");
                }
                break;
            case 2: // Search by ID
                String messageId = JOptionPane.showInputDialog(this, "Enter Message ID:");
                if (messageId != null && !messageId.trim().isEmpty()) {
                    Message found = messageManager.searchByMessageID(messageId.trim());
                    if (found != null) {
                        displayArea.setText("=== MESSAGE FOUND ===\n\n" +
                                          "ID: " + messageId + "\n" +
                                          "Recipient: " + found.getPhone() + "\n" + 
                                          "Message: " + found.getText() + "\n" +
                                          "Sender: " + found.getSender());
                    } else {
                        displayArea.setText("No message found with ID: " + messageId);
                    }
                }
                break;
            case 3: // Search by Recipient
                String recipient = JOptionPane.showInputDialog(this, "Enter Recipient Phone:");
                if (recipient != null && !recipient.trim().isEmpty()) {
                    Message[] results = messageManager.searchByRecipient(recipient.trim());
                    if (results.length > 0) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("=== MESSAGES TO ").append(recipient).append(" ===\n\n");
                        sb.append("Found ").append(results.length).append(" messages\n\n");
                        for (Message msg : results) {
                            sb.append("Message: ").append(msg.getText()).append("\n\n");
                        }
                        displayArea.setText(sb.toString());
                    } else {
                        displayArea.setText("No messages found for recipient: " + recipient);
                    }
                }
                break;
            case 4: // Delete by Hash
                String hash = JOptionPane.showInputDialog(this, "Enter Message Hash to delete:");
                if (hash != null && !hash.trim().isEmpty()) {
                    boolean deleted = messageManager.deleteMessageByHash(hash.trim());
                    if (deleted) {
                        displayArea.setText("Message with hash '" + hash + "' deleted successfully!\n" +
                                          "Remaining messages: " + messageManager.getSentCount());
                    } else {
                        displayArea.setText("No message found with hash: " + hash);
                    }
                }
                break;
            case 5: // Full Report
                displayArea.setText(messageManager.displayFullReport());
                break;
            case 6: // Run All Tests
                runAllTests();
                break;
            case 7: // Back to Main
                dispose();
                new MessagingForm(loggedInUser).setVisible(true);
                break;
        }
    }

    private void runAllTests() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== RUNNING ALL PART 3 TESTS ===\n\n");
        
        // Test 1: Arrays populated
        sb.append("1. Arrays Correctly Populated: ");
        sb.append(messageManager.getSentCount() > 0 ? "PASS\n" : "FAIL\n");
        
        // Test 2: Longest message
        Message longest = messageManager.displayLongestMessage();
        sb.append("2. Longest Message Found: ");
        sb.append(longest != null ? "PASS\n" : "FAIL\n");
        
        // Test 3: Search by ID
        if (messageManager.getSentCount() > 0) {
            String testId = messageManager.getMessageIDs()[0];
            Message found = messageManager.searchByMessageID(testId);
            sb.append("3. Search by Message ID: ");
            sb.append(found != null ? "PASS\n" : "FAIL\n");
        } else {
            sb.append("3. Search by Message ID: SKIP (no messages)\n");
        }
        
        // Test 4: Search by recipient  
        if (messageManager.getSentCount() > 0) {
            String testRecipient = messageManager.getSentMessages()[0].getPhone();
            Message[] results = messageManager.searchByRecipient(testRecipient);
            sb.append("4. Search by Recipient: ");
            sb.append(results.length > 0 ? "PASS\n" : "FAIL\n");
        } else {
            sb.append("4. Search by Recipient: SKIP (no messages)\n");
        }
        
        // Test 5: Delete functionality
        sb.append("5. Delete by Hash: TEST MANUALLY\n");
        
        // Test 6: Full report
        sb.append("6. Full Report: GENERATED\n\n");
        
        sb.append("=== TEST SUMMARY ===\n");
        sb.append("Total Tests: 6\n");
        sb.append("See detailed unit tests for complete validation.\n");
        
        displayArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdvancedMessagingForm("TestUser").setVisible(true));
    }
}