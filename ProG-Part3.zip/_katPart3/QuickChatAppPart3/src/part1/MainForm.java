package part1;

import javax.swing.*;
import java.awt.*;

public class MainForm extends JFrame {
    private JButton btnLogin, btnRegister, btnExit;

    public MainForm() {
        initUI();
        setLocationRelativeTo(null);
    }

    private void initUI() {
        setTitle("QuickChat - Main Menu");
        setSize(400, 240);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(0, 20));

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("Welcome to QuickChat!");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Button Panel
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 60, 30, 60));
        buttonPanel.setBackground(Color.WHITE);

        btnLogin = new JButton("Login");
        btnLogin.setBackground(Color.WHITE);
        btnLogin.setForeground(Color.BLACK);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btnLogin.setFocusPainted(false);
        btnLogin.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });

        btnRegister = new JButton("Register");
        btnRegister.setBackground(Color.WHITE);
        btnRegister.setForeground(Color.BLACK);
        btnRegister.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btnRegister.setFocusPainted(false);
        btnRegister.addActionListener(e -> {
            dispose();
            new RegisterForm().setVisible(true);
        });

        btnExit = new JButton("Exit");
        btnExit.setBackground(Color.WHITE);
        btnExit.setForeground(Color.BLACK);
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btnExit.setFocusPainted(false);
        btnExit.addActionListener(e -> System.exit(0));

        buttonPanel.add(btnLogin);
        buttonPanel.add(btnRegister);
        buttonPanel.add(btnExit);

        add(buttonPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainForm().setVisible(true));
    }
}