package part1;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class MessagingSystemTest {
    private MessageManager messageManager;
    private Message testMessage1, testMessage2, testMessage3, testMessage4;

    @Before
    public void setUp() {
        messageManager = new MessageManager();
        
        // Test data matching the specification requirements
        testMessage1 = new Message("System", "+27834557896", "Did you get the cake?");
        testMessage2 = new Message("System", "+2783886567", "Where are you? You are late!, I have asked you to be on time.");
        testMessage3 = new Message("System", "+2783886567", "Ok, I am leaving without you.");
        testMessage4 = new Message("System", "0888884567", "It is dinner time!");
        
        // Add messages using different actions to test all arrays
        messageManager.addMessage(testMessage1, "send");
        messageManager.addMessage(testMessage2, "send");
        messageManager.addMessage(testMessage3, "store");
        messageManager.addMessage(testMessage4, "discard");
    }

    // Test 1: Arrays correctly populated
    @Test
    public void testArraysCorrectlyPopulated() {
        Message[] sentMessages = messageManager.getSentMessages();
        Message[] storedMessages = messageManager.getStoredMessages();
        Message[] disregardedMessages = messageManager.getDisregardedMessages();
        String[] messageHashes = messageManager.getMessageHashes();
        String[] messageIDs = messageManager.getMessageIDs();
        
        // Test array sizes
        assertTrue("Sent messages array should contain messages", sentMessages.length >= 2);
        assertTrue("Stored messages array should contain messages", storedMessages.length >= 1);
        assertTrue("Disregarded messages array should contain messages", disregardedMessages.length >= 1);
        assertTrue("Message hashes array should contain hashes", messageHashes.length >= 3);
        assertTrue("Message IDs array should contain IDs", messageIDs.length >= 3);
        
        // Test specific content
        boolean foundCakeMessage = false;
        boolean foundDinnerMessage = false;
        
        for (Message msg : sentMessages) {
            if ("Did you get the cake?".equals(msg.getText())) {
                foundCakeMessage = true;
            }
        }
        
        for (Message msg : disregardedMessages) {
            if ("It is dinner time!".equals(msg.getText())) {
                foundDinnerMessage = true;
            }
        }
        
        assertTrue("Should contain 'Did you get the cake?' in sent messages", foundCakeMessage);
        assertTrue("Should contain 'It is dinner time!' in disregarded messages", foundDinnerMessage);
    }

    // Test 2: Display the longest message
    @Test
    public void testDisplayLongestMessage() {
        Message longest = messageManager.displayLongestMessage();
        assertNotNull("Longest message should not be null", longest);
        assertEquals("Longest message should be the late message", 
                    "Where are you? You are late!, I have asked you to be on time.", 
                    longest.getText());
        
        // Verify it's from sent messages
        assertEquals("Longest message should have 'send' action", "send", longest.getAction());
    }

    // Test 3: Search for message by ID
    @Test
    public void testSearchByMessageID() {
        // Get message1's ID and search for it
        String targetId = testMessage1.generateId();
        Message found = messageManager.searchByMessageID(targetId);
        
        assertNotNull("Should find message by ID", found);
        assertEquals("Found message ID should match", targetId, found.generateId());
        assertEquals("Found message content should match", "Did you get the cake?", found.getText());
        assertEquals("Found message recipient should match", "+27834557896", found.getPhone());
        
        // Test non-existent ID
        Message notFound = messageManager.searchByMessageID("NONEXISTENT123");
        assertNull("Should return null for non-existent ID", notFound);
    }

    // Test 4: Search all messages for a particular recipient
    @Test
    public void testSearchByRecipient() {
        Message[] results = messageManager.searchByRecipient("+2783886567");
        assertEquals("Should find 2 messages for recipient +2783886567", 2, results.length);
        
        boolean foundLateMessage = false;
        boolean foundLeavingMessage = false;
        
        for (Message msg : results) {
            if ("Where are you? You are late!, I have asked you to on time.".contains(msg.getText())) {
                foundLateMessage = true;
            }
            if ("Ok, I am leaving without you.".equals(msg.getText())) {
                foundLeavingMessage = true;
            }
        }
        
        assertTrue("Should contain late message", foundLateMessage);
        assertTrue("Should contain leaving message", foundLeavingMessage);
        
        // Test non-existent recipient
        Message[] emptyResults = messageManager.searchByRecipient("+27123456789");
        assertEquals("Should return empty array for non-existent recipient", 0, emptyResults.length);
    }

    // Test 5: Delete a message using message hash
    @Test
    public void testDeleteMessageByHash() {
        int initialCount = messageManager.getSentCount();
        String targetHash = testMessage1.generateHash(1);
        
        boolean deleted = messageManager.deleteMessageByHash(targetHash);
        assertTrue("Message should be deleted successfully", deleted);
        assertEquals("Sent count should decrease after deletion", initialCount - 1, messageManager.getSentCount());
        
        // Verify the message is gone
        Message shouldBeNull = messageManager.searchByMessageID(testMessage1.generateId());
        assertNull("Deleted message should not be found by ID", shouldBeNull);
        
        // Test deleting non-existent hash
        boolean notDeleted = messageManager.deleteMessageByHash("NONEXISTENT_HASH");
        assertFalse("Should return false for non-existent hash", notDeleted);
    }

    // Test 6: Display full report
    @Test
    public void testDisplayFullReport() {
        String report = messageManager.displayFullReport();
        assertNotNull("Report should not be null", report);
        assertTrue("Report should contain 'FULL MESSAGE REPORT' header", report.contains("FULL MESSAGE REPORT"));
        assertTrue("Report should contain message hashes", report.contains("Message Hash"));
        assertTrue("Report should contain recipients", report.contains("Recipient"));
        assertTrue("Report should contain messages", report.contains("Message"));
        assertTrue("Report should contain senders", report.contains("Sender"));
        assertTrue("Report should contain status", report.contains("Status"));
    }

    // Test 7: Message validation - length
    @Test
    public void testMessageLengthValidation() {
        // Test valid message
        Message validMessage = new Message("Test", "+27831234567", "This is a valid message");
        assertEquals("Valid message should pass length check", 
                    "Message ready to send.", 
                    validMessage.validateLength());
        
        // Test long message
        Message longMessage = new Message("Test", "+27831234567", 
            "This message is way too long and should fail the validation because it exceeds the 250 character limit. " +
            "This message is way too long and should fail the validation because it exceeds the 250 character limit. " +
            "This message is way too long and should fail the validation.");
        assertEquals("Long message should fail length check", 
                    "Message exceeds 250 character limit.", 
                    longMessage.validateLength());
    }

    // Test 8: Recipient phone validation
    @Test
    public void testRecipientPhoneValidation() {
        // Test valid South African number
        Message validSA = new Message("Test", "+27831234567", "Test message");
        assertEquals("Valid SA number should pass", 
                    "Cell phone number successfully captured.", 
                    validSA.validatePhone());
        
        // Test valid international number
        Message validInternational = new Message("Test", "+441234567890", "Test message");
        assertEquals("Valid international number should pass", 
                    "Cell phone number successfully captured.", 
                    validInternational.validatePhone());
        
        // Test invalid number
        Message invalidNumber = new Message("Test", "123", "Test message");
        assertEquals("Invalid number should fail", 
                    "Invalid international phone format.", 
                    invalidNumber.validatePhone());
        
        // Test null number
        Message nullNumber = new Message("Test", null, "Test message");
        assertEquals("Null number should fail", 
                    "Invalid international phone format.", 
                    nullNumber.validatePhone());
    }

    // Test 9: Message hash generation
    @Test
    public void testMessageHashGeneration() {
        Message testMessage = new Message("Test", "+27831234567", "Hello world this is a test");
        String hash = testMessage.generateHash(1);
        assertNotNull("Hash should not be null", hash);
        assertTrue("Hash should contain colon separators", hash.contains(":"));
        
        // Test with single word
        Message singleWord = new Message("Test", "+27831234567", "Hello");
        String singleHash = singleWord.generateHash(2);
        assertTrue("Single word hash should work", singleHash.contains("Hello"));
        
        // Test empty message
        Message emptyMessage = new Message("Test", "+27831234567", "");
        String emptyHash = emptyMessage.generateHash(3);
        assertEquals("Empty message should generate basic hash", ":3:", emptyHash);
    }

    // Test 10: Message ID generation
    @Test
    public void testMessageIDGeneration() {
        Message testMessage = new Message("TestSender", "+27831234567", "Test message content");
        String messageId = testMessage.generateId();
        
        assertNotNull("Message ID should not be null", messageId);
        assertTrue("Message ID should be 10 characters or checkable", 
                  messageId.length() <= 10 || testMessage.checkMessageID());
    }

    // Test 11: Message actions
    @Test
    public void testMessageActions() {
        Message testMessage = new Message("Test", "+27831234567", "Test message");
        
        assertEquals("Send action should return correct message", 
                    "Message successfully sent.", 
                    testMessage.performAction());
        
        testMessage.setAction("discard");
        assertEquals("Discard action should return correct message", 
                    "Press 0 to delete message.", 
                    testMessage.performAction());
        
        testMessage.setAction("store");
        assertEquals("Store action should return correct message", 
                    "Message successfully stored.", 
                    testMessage.performAction());
        
        testMessage.setAction("invalid");
        assertEquals("Invalid action should return unknown message", 
                    "Unknown action.", 
                    testMessage.performAction());
    }

    // Test 12: Array integrity and counts
    @Test
    public void testArrayIntegrityAndCounts() {
        assertEquals("Should have 2 sent messages", 2, messageManager.getSentCount());
        assertEquals("Should have 1 stored message", 1, messageManager.getStoredCount());
        assertEquals("Should have 1 disregarded message", 1, messageManager.getDisregardedCount());
        assertEquals("Should have 4 total messages", 4, messageManager.getMessageCount());
        
        // Test array contents match counts
        Message[] sent = messageManager.getSentMessages();
        Message[] stored = messageManager.getStoredMessages();
        Message[] disregarded = messageManager.getDisregardedMessages();
        
        assertEquals("Sent array length should match count", messageManager.getSentCount(), sent.length);
        assertEquals("Stored array length should match count", messageManager.getStoredCount(), stored.length);
        assertEquals("Disregarded array length should match count", messageManager.getDisregardedCount(), disregarded.length);
    }

    // Test 13: Integration with MessageStorage
    @Test
    public void testIntegrationWithMessageStorage() {
        // Save a new message
        Message newMessage = new Message("IntegrationTest", "+27839988776", "Integration test message");
        MessageStorage.saveMessage(newMessage);
        
        // Load and verify
        List<Message> storedMessages = MessageStorage.loadMessages();
        assertTrue("Should contain the new message", storedMessages.size() > 0);
        
        // Check if message exists in storage
        boolean found = false;
        for (Message msg : storedMessages) {
            if ("Integration test message".equals(msg.getText())) {
                found = true;
                break;
            }
        }
        assertTrue("Should find the integration test message in storage", found);
    }

    // Test 14: Edge cases
    @Test
    public void testEdgeCases() {
        // Test with empty manager
        MessageManager emptyManager = new MessageManager();
        assertNull("Empty manager should return null for longest message", 
                  emptyManager.displayLongestMessage());
        assertEquals("Empty manager should have zero sent count", 0, emptyManager.getSentCount());
        
        // Test search with empty manager
        Message[] emptyResults = emptyManager.searchByRecipient("+27123456789");
        assertEquals("Empty manager should return empty array", 0, emptyResults.length);
        
        // Test delete with empty manager
        boolean notDeleted = emptyManager.deleteMessageByHash("ANY_HASH");
        assertFalse("Empty manager should return false for delete", notDeleted);
    }

    // Test 15: Comprehensive functionality test
    @Test
    public void testComprehensiveFunctionality() {
        // Create a fresh manager for comprehensive test
        MessageManager testManager = new MessageManager();
        
        // Add various messages
        testManager.addMessage(new Message("User1", "+27831111111", "First test message"), "send");
        testManager.addMessage(new Message("User1", "+27832222222", "Second test message that is longer for testing"), "send");
        testManager.addMessage(new Message("User1", "+27833333333", "Third message"), "store");
        
        // Verify counts
        assertEquals("Should have 2 sent messages", 2, testManager.getSentCount());
        assertEquals("Should have 1 stored message", 1, testManager.getStoredCount());
        assertEquals("Should have 3 total messages", 3, testManager.getMessageCount());
        
        // Test longest message
        Message longest = testManager.displayLongestMessage();
        assertNotNull(longest);
        assertEquals("Longest message should be the second one", 
                    "Second test message that is longer for testing", 
                    longest.getText());
        
        // Test search
        Message[] user2Messages = testManager.searchByRecipient("+27832222222");
        assertEquals("Should find 1 message for recipient", 1, user2Messages.length);
        
        // Test full report
        String report = testManager.displayFullReport();
        assertNotNull(report);
        assertTrue(report.contains("FULL MESSAGE REPORT"));
    }
}