package part1;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class MessageTest {
    private Message message;
    
    @Before
    public void setUp() {
        message = new Message("John Doe", "+27123456789012", "Hello World Test", "Send");
    }
    
    @Test
    public void testValidateLength_ValidMessage() {
        Message msg = new Message("Sender", "+27123456789012", "Short message", "Send");
        assertEquals("Message ready to send.", msg.validateLength());
    }
    
    @Test
    public void testValidateLength_TooLong() {
        String longText = "a".repeat(251);
        Message msg = new Message("Sender", "+27123456789012", longText, "Send");
        assertEquals("Message exceeds 250 character limit.", msg.validateLength());
    }
    
    @Test
    public void testValidateLength_ExactLimit() {
        String exactText = "a".repeat(250);
        Message msg = new Message("Sender", "+27123456789012", exactText, "Send");
        assertEquals("Message ready to send.", msg.validateLength());
    }
    
    @Test
    public void testValidateLength_EmptyMessage() {
        Message msg = new Message("Sender", "+27123456789012", "", "Send");
        assertEquals("Message ready to send.", msg.validateLength());
    }
    
    @Test
    public void testValidatePhone_ValidInternational() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "Send");
        assertEquals("Cell phone number successfully captured.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_ValidMinLength() {
        Message msg = new Message("Sender", "+12345678901", "Test", "Send");
        assertEquals("Cell phone number successfully captured.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_ValidMaxLength() {
        Message msg = new Message("Sender", "+123456789012345", "Test", "Send");
        assertEquals("Cell phone number successfully captured.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_InvalidFormat() {
        Message msg = new Message("Sender", "0123456789", "Test", "Send");
        assertEquals("Invalid international phone format.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_TooShort() {
        Message msg = new Message("Sender", "+2712345", "Test", "Send");
        assertEquals("Invalid international phone format.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_TooLong() {
        Message msg = new Message("Sender", "+2712345678901234567", "Test", "Send");
        assertEquals("Invalid international phone format.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_MissingPlus() {
        Message msg = new Message("Sender", "27123456789012", "Test", "Send");
        assertEquals("Invalid international phone format.", msg.validatePhone());
    }
    
    @Test
    public void testValidatePhone_WithLetters() {
        Message msg = new Message("Sender", "+27ABC456789012", "Test", "Send");
        assertEquals("Invalid international phone format.", msg.validatePhone());
    }
    
    @Test
    public void testGenerateHash_TwoWords() {
        Message msg = new Message("Sender", "+27123456789012", "Hello World", "Send");
        String hash = msg.generateHash(1);
        assertEquals("Hello:1:World", hash);
    }
    
    @Test
    public void testGenerateHash_WithPunctuation() {
        Message msg = new Message("Sender", "+27123456789012", "Hello! World?", "Send");
        String hash = msg.generateHash(5);
        assertEquals("Hello:5:World", hash);
    }
    
    @Test
    public void testGenerateHash_SingleWord() {
        Message msg = new Message("Sender", "+27123456789012", "Hello", "Send");
        String hash = msg.generateHash(3);
        assertEquals("Hello:3:Hello", hash);
    }
    
    @Test
    public void testGenerateHash_MultipleWords() {
        Message msg = new Message("Sender", "+27123456789012", "The quick brown fox", "Send");
        String hash = msg.generateHash(10);
        assertEquals("The:10:fox", hash);
    }
    
    @Test
    public void testGenerateHash_WithNumbers() {
        Message msg = new Message("Sender", "+27123456789012", "Test123 Message456", "Send");
        String hash = msg.generateHash(2);
        assertEquals("Test:2:Message", hash);
    }
    
    @Test
    public void testGenerateId_NotNull() {
        assertNotNull(message.generateId());
    }
    
    @Test
    public void testGenerateId_Length() {
        String id = message.generateId();
        assertEquals(10, id.length());
    }
    
    @Test
    public void testGenerateId_Numeric() {
        String id = message.generateId();
        assertTrue(id.matches("\\d+"));
    }
    
    @Test
    public void testGenerateId_Consistency() {
        Message msg1 = new Message("Sender", "+27123456789012", "Test", "Send");
        String id1 = msg1.generateId();
        String id2 = msg1.generateId();
        assertEquals(id1, id2);
    }
    
    @Test
    public void testPerformAction_Send() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "Send");
        assertEquals("Message successfully sent.", msg.performAction());
    }
    
    @Test
    public void testPerformAction_SendCaseInsensitive() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "SEND");
        assertEquals("Message successfully sent.", msg.performAction());
    }
    
    @Test
    public void testPerformAction_Discard() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "Discard");
        assertEquals("Press 0 to delete message.", msg.performAction());
    }
    
    @Test
    public void testPerformAction_Store() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "Store");
        assertEquals("Message successfully stored.", msg.performAction());
    }
    
    @Test
    public void testPerformAction_Unknown() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "Unknown");
        assertEquals("Unknown action.", msg.performAction());
    }
    
    @Test
    public void testPerformAction_Empty() {
        Message msg = new Message("Sender", "+27123456789012", "Test", "");
        assertEquals("Unknown action.", msg.performAction());
    }
    
    @Test
    public void testGetSender() {
        assertEquals("John Doe", message.getSender());
    }
    
    @Test
    public void testGetPhone() {
        assertEquals("+27123456789012", message.getPhone());
    }
    
    @Test
    public void testGetText() {
        assertEquals("Hello World Test", message.getText());
    }
    
    @Test
    public void testGetAction() {
        assertEquals("Send", message.getAction());
    }
    
    @Test
    public void testConstructor_ThreeParameters() {
        Message msg = new Message("Sender", "+27111111111111", "Test message");
        assertNotNull(msg);
        assertEquals("Sender", msg.getSender());
        assertEquals("+27111111111111", msg.getPhone());
        assertEquals("Test message", msg.getText());
        assertEquals("Send", msg.getAction());
    }
    
    @Test
    public void testConstructor_FourParameters() {
        Message msg = new Message("Alice", "+27222222222222", "Hello", "Store");
        assertEquals("Alice", msg.getSender());
        assertEquals("+27222222222222", msg.getPhone());
        assertEquals("Hello", msg.getText());
        assertEquals("Store", msg.getAction());
    }
}