package part1;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import java.io.File;
import java.util.List;

public class LoginServiceTest {
    private static final String TEST_FILENAME = "users.json";
    
    @Before
    public void setUp() {
        deleteTestFile();
    }
    
    @After
    public void tearDown() {
        deleteTestFile();
    }
    
    private void deleteTestFile() {
        File file = new File(TEST_FILENAME);
        if (file.exists()) {
            file.delete();
        }
    }
    
    @Test
    public void testRegisterUser_NewUser() {
        boolean result = LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        assertTrue(result);
    }
    
    @Test
    public void testRegisterUser_DuplicateUsername() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        boolean result = LoginService.registerUser("Jane", "Smith", "jd_01", "Pass456!", "+27887654321");
        assertFalse(result);
    }
    
    @Test
    public void testRegisterUser_MultipleUsers() {
        assertTrue(LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678"));
        assertTrue(LoginService.registerUser("Jane", "Smith", "js_02", "Pass456!", "+27887654321"));
        assertTrue(LoginService.registerUser("Bob", "Brown", "bb_03", "Pass789!", "+27823456789"));
    }
    
    @Test
    public void testRegisterUser_DifferentData() {
        boolean result = LoginService.registerUser("Alice", "Wonder", "aw_99", "Secure@99", "+27856473829");
        assertTrue(result);
    }
    
    @Test
    public void testVerifyLogin_ValidCredentials() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        boolean result = LoginService.verifyLogin("jd_01", "Pass123!");
        assertTrue(result);
    }
    
    @Test
    public void testVerifyLogin_InvalidUsername() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        boolean result = LoginService.verifyLogin("wrong", "Pass123!");
        assertFalse(result);
    }
    
    @Test
    public void testVerifyLogin_InvalidPassword() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        boolean result = LoginService.verifyLogin("jd_01", "WrongPass");
        assertFalse(result);
    }
    
    @Test
    public void testVerifyLogin_NoUsers() {
        boolean result = LoginService.verifyLogin("jd_01", "Pass123!");
        assertFalse(result);
    }
    
    @Test
    public void testVerifyLogin_EmptyCredentials() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        assertFalse(LoginService.verifyLogin("", ""));
    }
    
    @Test
    public void testVerifyLogin_MultipleUsers() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        LoginService.registerUser("Jane", "Smith", "js_02", "Pass456!", "+27887654321");
        assertTrue(LoginService.verifyLogin("jd_01", "Pass123!"));
        assertTrue(LoginService.verifyLogin("js_02", "Pass456!"));
    }
    
    @Test
    public void testGetUserFullName_ValidUser() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        String fullName = LoginService.getUserFullName("jd_01");
        assertEquals("John Doe", fullName);
    }
    
    @Test
    public void testGetUserFullName_InvalidUser() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        String fullName = LoginService.getUserFullName("invalid");
        assertEquals("invalid", fullName);
    }
    
    @Test
    public void testGetUserFullName_NoUsers() {
        String fullName = LoginService.getUserFullName("jd_01");
        assertEquals("jd_01", fullName);
    }
    
    @Test
    public void testGetUserFullName_MultipleUsers() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        LoginService.registerUser("Jane", "Smith", "js_02", "Pass456!", "+27887654321");
        assertEquals("John Doe", LoginService.getUserFullName("jd_01"));
        assertEquals("Jane Smith", LoginService.getUserFullName("js_02"));
    }
    
    @Test
    public void testGetUserNames_EmptyList() {
        List<String> usernames = LoginService.getUserNames();
        assertNotNull(usernames);
        assertEquals(0, usernames.size());
    }
    
    @Test
    public void testGetUserNames_MultipleUsers() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        LoginService.registerUser("Jane", "Smith", "js_02", "Pass456!", "+27887654321");
        LoginService.registerUser("Bob", "Brown", "bb_03", "Pass789!", "+27823456789");
        
        List<String> usernames = LoginService.getUserNames();
        assertEquals(3, usernames.size());
        assertTrue(usernames.contains("jd_01"));
        assertTrue(usernames.contains("js_02"));
        assertTrue(usernames.contains("bb_03"));
    }
    
    @Test
    public void testGetUserNames_SingleUser() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        List<String> usernames = LoginService.getUserNames();
        assertEquals(1, usernames.size());
        assertEquals("jd_01", usernames.get(0));
    }
    
    @Test
    public void testUserData_Constructor() {
        LoginService.UserData user = new LoginService.UserData(
            "John", "Doe", "jd_01", "Pass123!", "+27812345678"
        );
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
        assertEquals("jd_01", user.getUsername());
        assertEquals("Pass123!", user.getPassword());
        assertEquals("+27812345678", user.getPhone());
    }
    
    @Test
    public void testUserData_AllFields() {
        LoginService.UserData user = new LoginService.UserData(
            "Alice", "Wonder", "aw_99", "Secure@99", "+27856473829"
        );
        assertEquals("Alice", user.getFirstName());
        assertEquals("Wonder", user.getLastName());
        assertEquals("aw_99", user.getUsername());
        assertEquals("Secure@99", user.getPassword());
        assertEquals("+27856473829", user.getPhone());
    }
    
    @Test
    public void testPersistence_DataSavedAndLoaded() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        boolean loginSuccessful = LoginService.verifyLogin("jd_01", "Pass123!");
        assertTrue(loginSuccessful);
        File file = new File(TEST_FILENAME);
        assertTrue(file.exists());
    }
    
    @Test
    public void testPersistence_MultipleRegistrations() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        LoginService.registerUser("Jane", "Smith", "js_02", "Pass456!", "+27887654321");
        List<String> usernames = LoginService.getUserNames();
        assertEquals(2, usernames.size());
    }
    
    @Test
    public void testRegisterUser_AfterDuplicate() {
        LoginService.registerUser("John", "Doe", "jd_01", "Pass123!", "+27812345678");
        LoginService.registerUser("Jane", "Smith", "jd_01", "Pass456!", "+27887654321");
        String fullName = LoginService.getUserFullName("jd_01");
        assertEquals("John Doe", fullName);
    }
}